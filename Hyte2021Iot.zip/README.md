# mikä on Iot
 

## Sääasemajärjestelmän toimintakaavio


###### Laitteistot
###### Komponentit
###### Palvelut
###### Ohjelmointi
###### Toiminta

# Käytetyt kehitysympäristöt
# Termihakemisto
# Viitteet